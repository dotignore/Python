from django.contrib import admin
from .models import Month

admin.site.register(Month)
