from django.apps import AppConfig


class MoneyConfig(AppConfig):
    name = 'money'
