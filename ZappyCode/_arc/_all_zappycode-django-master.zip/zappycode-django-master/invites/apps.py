from django.apps import AppConfig


class InvitesConfig(AppConfig):
    name = 'invites'
