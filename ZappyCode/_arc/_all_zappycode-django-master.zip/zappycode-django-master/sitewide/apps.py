from django.apps import AppConfig


class SitewideConfig(AppConfig):
    name = 'sitewide'
