from django.apps import AppConfig


class ChallengeConfig(AppConfig):
    name = 'challenge'
